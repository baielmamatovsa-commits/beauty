document.addEventListener('DOMContentLoaded', function() {
  console.log('Project nurzhan is ready!');
});